import 'package:flutter/material.dart';

const colorbase = Color(0xFF18141D);
const appbarcolor = Color(0xffb28242c);
