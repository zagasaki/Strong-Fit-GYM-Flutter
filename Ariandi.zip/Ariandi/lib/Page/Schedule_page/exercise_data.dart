Map<String, int> exerciseData = {
  "Morning: 30 minutes of jogging": 200,
  "Afternoon: 20 minutes of bodyweight exercises": 150,
  "Evening: Yoga for relaxation": 100,
};
