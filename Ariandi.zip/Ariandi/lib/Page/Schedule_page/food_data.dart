Map<String, String> foodRecommendations = {
  "Monday":
      "Breakfast: Scrambled eggs with toast\nLunch: Caesar salad\nSnack: Apple slices\nDinner: Grilled salmon with quinoa",
  "Tuesday":
      "Breakfast: Greek yogurt with berries\nLunch: Turkey sandwich\nSnack: Mixed nuts\nDinner: Vegetarian stir-fry",
  "Wednesday":
      "Breakfast: Oatmeal with banana\nLunch: Caprese sandwich\nSnack: Carrot sticks\nDinner: Baked chicken with sweet potatoes",
  "Thursday":
      "Breakfast: Smoothie with spinach and berries\nLunch: Quinoa salad\nSnack: Orange slices\nDinner: Shrimp stir-fry",
  "Friday":
      "Breakfast: Avocado toast\nLunch: Tuna salad wrap\nSnack: Greek yogurt with granola\nDinner: Beef and vegetable kebabs",
  "Saturday":
      "Breakfast: Pancakes with maple syrup\nLunch: Chicken caesar wrap\nSnack: Trail mix\nDinner: Spaghetti with marinara sauce",
  "Sunday":
      "Breakfast: Bagel with cream cheese\nLunch: Spinach and feta omelette\nSnack: Pear slices\nDinner: Grilled steak with asparagus",
};
